import { seed } from "drizzle-seed";
import { db } from "./db/index.js";
import { posts } from "./db/schema.js";

async function main() {
  await seed(db, posts, { count: 20 });
}


main()