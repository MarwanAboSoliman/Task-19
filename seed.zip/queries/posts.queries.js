import { db } from "../db/index.js";
import { posts, users, likes, comments } from "../db/schema.js";
import { eq, sql, like, desc } from "drizzle-orm";

//create post

export async function createPost({ userId, content, image }) {
  const [post] = await db
    .insert(posts)
    .values({ userId, content, image })
    .returning();
  return post;
}

//getAll

export async function getAllPosts(currentUserId) {
  return db
    .select({
      id: posts.id,
      content: posts.content,
      image: posts.image,
      created_at: posts.createdAt,
      username: users.username,
      like_count: sql`(select count(*)::int from ${likes} where ${likes.postId} = ${posts.id})`,
      comment_count: sql`(select count(*)::int from ${comments} where ${comments.postId} = ${posts.id})`,
      liked_by_me: sql`exists (select 1 from ${likes} where ${likes.postId} = ${posts.id} and ${likes.userId} = ${currentUserId})`,
    })
    .from(posts)
    .innerJoin(users, eq(posts.userId, users.id))
    .orderBy(desc(posts.createdAt));
}

//get post by id

export async function getPostById(postID, currentUserId = null) {
  // Fetch the post
  const [post] = await db
    .select({
      id: posts.id,
      content: posts.content,
      image: posts.image,
      created_at: posts.createdAt,
      username: users.username,
      like_count: sql`(select count(*)::int from ${likes} where ${likes.postId} = ${posts.id})`,
      comment_count: sql`(select count(*)::int from ${comments} where ${comments.postId} = ${posts.id})`,
      liked_by_me: currentUserId
        ? sql`exists (
            select 1 from ${likes}
            where ${likes.postId} = ${posts.id}
            and ${likes.userId} = ${currentUserId}
          )`
        : sql`false`,
    })
    .from(posts)
    .innerJoin(users, eq(posts.userId, users.id))
    .where(eq(posts.id, postID));

  if (!post) return null;

  const commentsList = await db
    .select({
      id: comments.id,
      content: comments.content,
      created_at: comments.createdAt,
      username: users.username,
    })
    .from(comments)
    .innerJoin(users, eq(comments.userId, users.id))
    .where(eq(comments.postId, postID));

  return { post, comments: commentsList };
}
