export function checkAuth(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({
      error: "unauthorized",
    });
  }
  next();
}
